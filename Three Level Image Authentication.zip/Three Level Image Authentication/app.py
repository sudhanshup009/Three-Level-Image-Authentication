from flask import Flask, render_template, request

from database import create_database, add_user, get_user
from password_auth import hash_password, check_password
from image_auth import check_image_password
from otp_auth import generate_otp, verify_otp, can_resend_otp, resend_otp
from email_service import send_otp_email


app = Flask(__name__)


# Home page
@app.route("/")
def home():

    return render_template("index.html")


# Login
@app.route("/login", methods=["GET", "POST"])
def login():

    # Show login page
    if request.method == "GET":

        return render_template("login.html")

    # Get login details
    username = request.form["username"]
    password = request.form["password"]

    # Find user
    user = get_user(username)

    if user is None:

        return "User not found!"


    # Check password
    if check_password(password, user[2]):

        return render_template(
            "image_login.html",
            username=username
        )

    return "Wrong password!"


# Register
@app.route("/register", methods=["GET", "POST"])
def register():

    # Show register page
    if request.method == "GET":

        return render_template("register.html")

    # Get registration details
    username = request.form["username"]
    email = request.form["email"]
    password = request.form["password"]
    image_password = request.form["image_password"]

    # Hash password
    hashed_password = hash_password(password)

    # Add user
    add_user(
        username,
        email,
        hashed_password,
        image_password
    )

    return "Registration successful!"


# Level 2 - Image Authentication
@app.route("/image-login", methods=["POST"])
def image_login():

    username = request.form["username"]

    selected_images = request.form["image_password"]

    selected_images = selected_images.split(",")

    user = get_user(username)

    if user is None:

        return "User not found!"


    # Check image password
    if check_image_password(user[3], selected_images):

        # Generate OTP
        otp = generate_otp(username)

        email = user[1]

        # Send OTP
        if send_otp_email(email, otp):

            return render_template(
                "otp.html",
                username=username
            )

        return "OTP could not be sent!"

    return "Wrong image password!"


# Resend OTP
@app.route("/resend-otp", methods=["POST"])
def resend_otp_page():

    username = request.form["username"]

    allowed, remaining = can_resend_otp(username)

    if not allowed:

        return f"Please wait {remaining} seconds before requesting a new OTP."

    user = get_user(username)

    if user is None:

        return "User not found!"

    otp = resend_otp(username)

    email = user[1]

    if send_otp_email(email, otp):

        return render_template(
            "otp.html",
            username=username
        )

    return "OTP could not be sent!"


# Level 3 - OTP Authentication
@app.route("/verify-otp", methods=["POST"])
def verify_otp_page():

    username = request.form["username"]

    entered_otp = request.form["otp"]

    # Check OTP
    if verify_otp(username, entered_otp):

        return """
        <h1>Access Granted!</h1>

        <p>
        All three authentication levels passed successfully.
        </p>
        """

    return "Wrong or expired OTP!"


# Run application
if __name__ == "__main__":

    create_database()

    app.run(debug=True)